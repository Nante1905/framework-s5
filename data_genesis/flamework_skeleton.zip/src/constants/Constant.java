package constants;

public class Constant {
    public static final int TAILLE_PAGE = 5;
}