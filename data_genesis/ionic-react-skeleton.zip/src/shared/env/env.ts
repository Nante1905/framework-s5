export const URL_API = "http://localhost:8080/[projectNameMaj]";
