import { archiveSharp } from "ionicons/icons";
import ProduitListe from "../../components/produit/produit-liste.component";
import { PageInfo } from "../types/PageInfo";

export const AppPages: PageInfo[] = [
  {
    path: "/produit",
    title: "Produit",
    component: <ProduitListe />,
    icon: archiveSharp,
  },
  {
    path: "/test",
    title: "Produit",
    component: <ProduitListe />,
    icon: archiveSharp,
  },
  {
    path: "/marque",
    title: "Produit",
    component: <ProduitListe />,
    icon: archiveSharp,
  },
];
