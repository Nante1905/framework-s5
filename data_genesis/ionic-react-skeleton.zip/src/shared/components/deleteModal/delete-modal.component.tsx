import { Button, CircularProgress } from "@mui/material";

interface DeleteModalProps {
  onClose: () => void;
  onConfirm: () => void;
  loading: boolean;
}

interface DeleteModalState {
  success: string | null;
  error: string | null;
  loading: boolean;
}

const initialState: DeleteModalState = {
  success: null,
  error: null,
  loading: false,
};

const DeleteModal = (props: DeleteModalProps) => {
  return (
    <div>
      <p className="text-center">Voulez-vous vraiment supprimé cette entité?</p>
      <div className="inline-flex">
        <Button variant="contained" onClick={props.onClose}>
          Annuler
        </Button>
        <Button
          variant="contained"
          className="div-danger"
          onClick={() => props.onConfirm()}
        >
          {props.loading ? <CircularProgress /> : <>Confirmer</>}
        </Button>
      </div>
    </div>
  );
};

export default DeleteModal;
