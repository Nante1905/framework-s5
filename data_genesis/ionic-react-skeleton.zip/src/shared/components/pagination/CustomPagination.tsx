import SearchIcon from "@mui/icons-material/Search";
import { Button, Pagination, TextField } from "@mui/material";
import { useEffect, useState } from "react";
import "./CustomPagination.scss";

interface PaginationProps {
  total: number;
  page: number;
  pageSize: number;
  changePage: (page: number) => void;
  changePageSize: (pageSize: number) => void;
}

interface CustomPaginationState {
  error: string | null;
  nbrPage: number;
}

const CustomPagination = (props: PaginationProps) => {
  const [state, setState] = useState<CustomPaginationState>({
    error: null,
    nbrPage: props.pageSize,
  });

  useEffect(() => {
    setState((state) => ({
      ...state,
      nbrPage: props.pageSize,
    }));
  }, []);

  return (
    <div id="pagination">
      <div className="pagination_container">
        <TextField
          label={`${props.pageSize}`}
          type="number"
          className="input"
          InputProps={{
            inputProps: {
              min: 1,
            },
          }}
          // value={state.nbrPage}
          onChange={(event) => {
            setState((state) => ({
              ...state,
              error: null,
            }));
            const value = Number(event.target.value);
            if (value < 1) {
              setState((state) => ({
                ...state,
                error: "Le nombre d'élément par page doit être supérieur à 0.",
              }));
            } else {
              setState((state) => ({
                ...state,
                nbrPage: value,
              }));
            }
          }}
        />
        <Button onClick={() => props.changePageSize(state.nbrPage)}>
          <SearchIcon />
        </Button>
        <Pagination
          count={props.total}
          variant="outlined"
          color="primary"
          defaultPage={props.page}
          boundaryCount={2}
          onChange={(_event, page) => {
            props.changePage(page);
          }}
        />
      </div>
      {state.error != null && (
        <p className="text-center text-danger">{state.error}</p>
      )}
    </div>
  );
};

export default CustomPagination;
