export interface Marque {
    idmarque?: number,
    nom?: string
}