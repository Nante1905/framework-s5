export interface PageInfo {
    path: string;
    title: string;
    component: JSX.Element;
    icon: string
}