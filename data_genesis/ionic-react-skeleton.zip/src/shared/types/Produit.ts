import { Marque } from "./Marque"

export interface Produit {
    idproduit?: number,
    nom: string,
    prix: number,
    marque: Marque
    disponibilite: number
}