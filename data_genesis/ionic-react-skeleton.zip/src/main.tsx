import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import { AppPages } from "./shared/data/PageInfo";
import { PageInfo } from "./shared/types/PageInfo";

const container = document.getElementById("root");
const root = createRoot(container!);

const pages: PageInfo[] = AppPages;
root.render(
  <React.StrictMode>
    <App pages={pages} />
  </React.StrictMode>
);

