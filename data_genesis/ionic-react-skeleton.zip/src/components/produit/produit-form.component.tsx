import {
  Button,
  CircularProgress,
  FormControl,
  InputLabel,
  MenuItem,
  Select,
  TextField,
} from "@mui/material";
import axios from "axios";
import qs from "qs";
import { FormEvent, useEffect, useState } from "react";
import ErrorSnackBar from "../../shared/components/snackbar/ErrorSnackBar";
import SuccessSnackBar from "../../shared/components/snackbar/SuccessSnackBar";
import { URL_API } from "../../shared/env/env";
import { Marque } from "../../shared/types/Marque";
import { Produit } from "../../shared/types/Produit";

const ProduitForm = (props: ProduitProps) => {
  const [state, setState] = useState<ProduitState>(initialState);
  useEffect(() => {
    if (props.id) {
      // get produit by id: TODO: ovaina ito url io
      setState((state) => ({
        ...state,
        loading: true,
      }));
      axios
        .get(`${URL_API}/produit.do?idproduit=${props.id}`)
        .then((res) => {
          console.log(res);

          setState((state) => ({
            ...state,
            form: res.data.data[0],
            loading: false,
          }));
        })
        .catch((err) => {
          let errorMessage = "Une erreur s'est produite";
          if (
            err.response?.data.err &&
            err.response?.data.err != "" &&
            err.response?.data.err != null
          ) {
            errorMessage = err.response.data.err;
          }
          setState((state) => ({
            ...state,
            error: errorMessage,
            loading: false,
          }));
        });
    }
  }, []);

  useEffect(() => {
    // maka foreing key
    setState((state) => ({
      ...state,
      loading: true,
    }));
    axios
      .get(`${URL_API}/marque.do`)
      .then((res) => {
        setState((state) => ({
          ...state,
          loading: false,
          marque: res.data.data,
        }));
      })
      .catch((err) => {
        let errorMessage = "Une erreur s'est produite";
        if (
          err.response?.data.err &&
          err.response?.data.err != "" &&
          err.response?.data.err != null
        ) {
          errorMessage = err.response.data.err;
        }
        setState((state) => ({
          ...state,
          error: errorMessage,
          loading: false,
        }));
      });
  }, []);

  // TODO
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setState((state) => ({
      ...state,
      sendLoading: true,
    }));
    let url = `${URL_API}/insertproduit.do`;
    if (props.id) {
      url = `${URL_API}/updateproduit.do`;
    }
    const options = {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      data: qs.stringify({
        ...state.form,
        marque: state.form.marque.idmarque,
      }),
      url,
    };
    axios(options)
      .then((res) => {
        console.log(res);
        setState((state) => ({
          ...state,
          success: "Enregistré",
          sendLoading: false,
        }));
        if (props.onClose) {
          props.onClose();
        }
      })
      .catch((err) => {
        let errorMessage = "Une erreur s'est produite";
        if (
          err.response?.data.err &&
          err.response?.data.err != "" &&
          err.response?.data.err != null
        ) {
          errorMessage = err.response.data.err;
        }
        setState((state) => ({
          ...state,
          error: errorMessage,
          sendLoading: false,
        }));
      });
  };

  return (
    <>
      <div className="crud-form-wrapper">
        <h1 className="text-center">
          {props.id ? "Modification" : "Création"} Produit
        </h1>
        {state.loading ? (
          <CircularProgress />
        ) : (
          <form
            className="form-content"
            onSubmit={(event) => handleSubmit(event)}
          >
            <div className="form-input">
              <TextField
                label="Nom"
                onChange={(event) =>
                  setState((state) => ({
                    ...state,
                    form: {
                      ...state.form,
                      nom: event.target.value as string,
                    },
                  }))
                }
                value={state.form.nom}
              />
            </div>
            <div className="form-input">
              {state.loading ? (
                <CircularProgress />
              ) : (
                <FormControl sx={{ width: 200 }}>
                  <InputLabel id="demo-simple-select-label">Marque</InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={state.form?.marque?.idmarque}
                    label="Marque"
                    onChange={(event) => {
                      setState((state) => ({
                        ...state,
                        form: {
                          ...state.form,
                          marque: {
                            idmarque: event.target.value as number,
                          },
                        },
                      }));
                    }}
                  >
                    {state.marque?.map((e: Marque, i) => (
                      <MenuItem key={`fk${i}`} value={e?.idmarque}>
                        {e.nom}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              )}
            </div>
            {/* Raha date */}
            {/* <FormControl>
              <LocalizationProvider
                dateAdapter={AdapterDayjs}
                adapterLocale="fr"
              >
                <DatePicker
                  label={"Raha misy date"}
                  format="DD/MM/YYYY"
                  onChange={(value: Dayjs | null) => {
                    setState((state) => ({
                      ...state,
                      form: {
                        ...state.form,
                        nom: value?.format("YYYY-MM-DD") as string,
                      },
                    }));
                  }}
                  value={dayjs(state.form.nom as string)}
                />
              </LocalizationProvider>
            </FormControl> */}
            <div className="form-input">
              <TextField
                label="Prix"
                onChange={(event) =>
                  setState((state) => ({
                    ...state,
                    form: {
                      ...state.form,
                      prix: Number(event.target.value),
                    },
                  }))
                }
                value={state.form.prix}
              />
            </div>
            <div className="inline-flex-center vertical-margin">
              <Button variant="contained" type="submit">
                {state.sendLoading ? <CircularProgress /> : <>Valider</>}
              </Button>
            </div>
          </form>
        )}
      </div>
      <ErrorSnackBar
        open={state.error != null}
        onClose={() =>
          setState(() => ({
            ...state,
            error: null,
          }))
        }
        error={state.error as string}
      />
      <SuccessSnackBar
        open={state.success != null}
        onClose={() =>
          setState(() => ({
            ...state,
            success: null,
          }))
        }
        message={state.success as string}
      />
    </>
  );
};

interface ProduitProps {
  id?: string;
  onClose?: () => void;
}

interface ProduitState {
  form: Produit;
  loading: boolean;
  sendLoading: boolean;
  error: string | null;
  success: string | null;
  marque: Marque[];
}

const initialState: ProduitState = {
  form: {
    nom: "",
    prix: 0,
    marque: {
      idmarque: 0,
    },
    disponibilite: 0,
  },
  loading: false,
  sendLoading: false,
  error: null,
  success: null,
  marque: [],
};

export default ProduitForm;
