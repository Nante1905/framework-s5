import {
  IonApp,
  IonRouterOutlet,
  IonSplitPane,
  setupIonicReact,
} from "@ionic/react";
import { IonReactRouter } from "@ionic/react-router";
import { Route } from "react-router-dom";
import Menu from "./components/Menu";
/* Core CSS required for Ionic components to work properly */
import "@ionic/react/css/core.css";

/* Basic CSS for apps built with Ionic */
import "@ionic/react/css/normalize.css";
import "@ionic/react/css/structure.css";
import "@ionic/react/css/typography.css";

/* Optional CSS utils that can be commented out */
import "@ionic/react/css/display.css";
import "@ionic/react/css/flex-utils.css";
import "@ionic/react/css/float-elements.css";
import "@ionic/react/css/padding.css";
import "@ionic/react/css/text-alignment.css";
import "@ionic/react/css/text-transformation.css";

/* Theme variables */
import LandingPage from "./components/landing-page/LandingPage";
import Page from "./pages/Page";
import { PageInfo } from "./shared/types/PageInfo";
import "./theme/global.scss";
import "./theme/variables.css";

setupIonicReact();

interface AppProps {
  pages: PageInfo[];
}

const App = (props: AppProps) => {
  return (
    <IonApp>
      <IonReactRouter>
        <IonSplitPane contentId="main">
          <Menu />
          <IonRouterOutlet id="main">
            {props.pages.map((p, i) => (
              <Route path={p.path} exact={true} key={p.path}>
                <Page title={p.title}>{p.component}</Page>
              </Route>
            ))}
            <Route path="/" exact={true}>
              <Page title="Home">
                <LandingPage />
              </Page>
            </Route>
          </IonRouterOutlet>
        </IonSplitPane>
      </IonReactRouter>
    </IonApp>
  );
};

export default App;

