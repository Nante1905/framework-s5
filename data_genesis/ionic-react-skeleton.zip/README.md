# react-skeleton

- tsy url getById
- theme an'ilay app
- /src/shared/env koa mila réecriture

-mila import ionic/react
-icon ray am MUI

- useLocation
- css

-type import:

- import membre misy {...} from
- import précis tsy misy accolade
- non précis tsisy an'ireo fa import '...'

MODIF
-atao anaty div.form-input lay date
-atao nom readable an'ilay entité ny titre onglet
-soloina an'ito ny template

-ilay landing page mila atao ato
